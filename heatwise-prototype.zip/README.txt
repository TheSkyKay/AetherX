Heatwise prototype

Contents
- index.html: website
- server.js: local web server and Open-Meteo gateway

Run locally
1. Install Node.js if it is not already installed.
2. Open a terminal in this folder.
3. Run: node server.js
4. Visit: http://localhost:4173

Phone on the same Wi-Fi
Run ipconfig on the computer, find the IPv4 address under the active Wi-Fi adapter, then open http://COMPUTER-IP:4173 on the phone. Allow Node.js on private networks if Windows asks.

The weather and map layers require internet access. Windy is currently embedded as its public temperature-map widget. Open-Meteo forecasts and historical weather go through the local gateway.
