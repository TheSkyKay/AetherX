// Local same-origin gateway for the Heatwise demo.
// Run with: node server.js, then open http://localhost:4173
const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');

const PORT = Number(process.env.PORT || 4173);
const ROOT = __dirname;
const cache = new Map();
const cacheMs = 5 * 60 * 1000;

const upstreams = {
  '/api/open-meteo/forecast': 'https://api.open-meteo.com/v1/forecast',
  '/api/open-meteo/archive': 'https://archive-api.open-meteo.com/v1/archive',
  '/api/open-meteo/geocoding': 'https://geocoding-api.open-meteo.com/v1/search',
};

function send(res, status, body, type = 'application/json; charset=utf-8') {
  res.writeHead(status, { 'Content-Type': type, 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' });
  res.end(body);
}

const server = http.createServer(async (req, res) => {
  const incoming = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const upstream = upstreams[incoming.pathname];
  if (upstream) {
    if (req.method !== 'GET') return send(res, 405, JSON.stringify({ error: 'GET only' }));
    const key = incoming.pathname + incoming.search;
    const cached = cache.get(key);
    if (cached && Date.now() - cached.at < cacheMs) return send(res, 200, cached.body);
    try {
      const target = new URL(upstream);
      incoming.searchParams.forEach((value, name) => target.searchParams.set(name, value));
      const response = await fetch(target, { headers: { Accept: 'application/json' }, signal: AbortSignal.timeout(15000) });
      const body = await response.text();
      if (!response.ok) return send(res, response.status, JSON.stringify({ error: 'Open-Meteo request failed', status: response.status }));
      cache.set(key, { at: Date.now(), body });
      return send(res, 200, body);
    } catch (error) {
      return send(res, 502, JSON.stringify({ error: 'Could not reach Open-Meteo', detail: error.message }));
    }
  }

  if (incoming.pathname === '/' || incoming.pathname === '/index.html') {
    try { return send(res, 200, fs.readFileSync(path.join(ROOT, 'index.html')), 'text/html; charset=utf-8'); }
    catch { return send(res, 500, 'Could not read index.html', 'text/plain; charset=utf-8'); }
  }
  return send(res, 404, 'Not found', 'text/plain; charset=utf-8');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Heatwise gateway ready on port ${PORT}; open http://<your-computer-ip>:${PORT} from another device on the same Wi-Fi`);
  console.log('Open that address in your browser. Press Ctrl+C to stop the gateway.');
});
